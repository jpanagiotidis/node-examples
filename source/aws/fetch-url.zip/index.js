'use strict';

const request = require('request');

exports.handler = (event, context, callback) => {
  request(event.url, function(error, response, html) {
    if (!error && response.statusCode == 200) {
      callback(null, html);
    }else{
      callback(error);
    }
  });
};
